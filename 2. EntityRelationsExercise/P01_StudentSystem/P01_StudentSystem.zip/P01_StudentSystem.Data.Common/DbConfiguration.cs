﻿namespace P01_StudentSystem.Data.Common;

public static class DbConfiguration
{
    public const string SqlConnectionString = @"Server=localhost;DataBase=StudentSystem;Integrated Security=True;MultipleActiveResultSets=true;TrustServerCertificate=true";
}
