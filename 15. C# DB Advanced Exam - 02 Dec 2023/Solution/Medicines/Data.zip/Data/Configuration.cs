﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"server=localhost;Database=Medicines;Integrated Security=True;Encrypt=False;";
    }
}
