﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"server=localhost;Database=Cadastre;Integrated Security=True;Encrypt=False";
    }
}
