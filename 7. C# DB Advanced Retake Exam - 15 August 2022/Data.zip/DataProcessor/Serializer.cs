﻿

using Newtonsoft.Json;
using Trucks.DataProcessor.ExportDto;
using Trucks.Utilities;

namespace Trucks.DataProcessor
{
    using Data;
    using Trucks.Data.Models.Enums;

    public class Serializer
    {
        
        public static string ExportDespatchersWithTheirTrucks(TrucksContext context)
        {
            var despatchers = context.Despatchers
                .ToArray()
                .Where(d => d.Trucks.Any())
                .Select(d => new ExportDespatcherDto()
                {
                    DespatcherName = d.Name,
                    TrucksCount = d.Trucks.Count,
                    Trucks = d.Trucks
                        .Select(t => new ExportTruckDto()
                        {
                            RegistrationNumber = t.RegistrationNumber,
                            Make = t.MakeType.ToString()
                        })
                        .OrderBy(t => t.RegistrationNumber)
                        .ToArray()
                })
                .OrderByDescending(d => d.Trucks.Length)
                .ThenBy(d => d.DespatcherName)
                .ToArray();

            XmlHelper xmlHelper = new XmlHelper();

            return xmlHelper.Serialize(despatchers, "Despatchers");
        }
        
        public static string ExportClientsWithMostTrucks(TrucksContext context, int capacity)
        {
            var clients = context.Clients
                .ToArray()
                .Where(c => c.ClientsTrucks.Any(tc => tc.Truck.TankCapacity >= capacity))
                .Select(c => new
                {
                    Name = c.Name,
                    Trucks = c.ClientsTrucks
                        .ToArray()
                        .Where(tc => tc.Truck.TankCapacity >= capacity)
                        .Select(tc => new
                        {
                            TruckRegistrationNumber = tc.Truck.RegistrationNumber,
                            VinNumber = tc.Truck.VinNumber,
                            TankCapacity = tc.Truck.TankCapacity,
                            CargoCapacity = tc.Truck.CargoCapacity,
                            CategoryType = tc.Truck.CategoryType.ToString(),
                            MakeType = tc.Truck.MakeType.ToString()
                        })
                        .OrderBy(tc => tc.MakeType)
                        .ThenByDescending(tc => tc.CargoCapacity)
                        .ToArray()
                })
                .OrderByDescending(c => c.Trucks.Length)
                .ThenBy(c => c.Name)
                .Take(10)
                .ToArray();

            return JsonConvert.SerializeObject(clients, Formatting.Indented);
        }
    }
}
