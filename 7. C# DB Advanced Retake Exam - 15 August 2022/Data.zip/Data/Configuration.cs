﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"server=localhost;Database=Trucks;Trusted_Connection=True";
    }
}